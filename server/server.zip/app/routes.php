<?php

declare(strict_types=1);

use App\Controllers\AuthController;
use App\Controllers\ClientController;
use App\Controllers\ConfigController;
use App\Controllers\DashboardController;
use App\Controllers\HealthController;
use App\Controllers\KundliController;

$router = new \App\Core\Router();

// Public API
$router->get('/api/v1/health', [HealthController::class, 'index']);
$router->get('/api/v1/config', [ConfigController::class, 'index']);
$router->post('/api/v1/client', [ClientController::class, 'heartbeat']);
$router->post('/api/v1/kundli', [KundliController::class, 'save']);

// Admin auth
$router->get('/admin/login', [AuthController::class, 'showLogin']);
$router->post('/admin/login', [AuthController::class, 'login']);
$router->get('/admin/logout', [AuthController::class, 'logout']);

// Admin dashboard (authed)
$router->get('/admin', [DashboardController::class, 'index'], ['middleware' => 'auth']);
$router->get('/admin/clients', [DashboardController::class, 'clients'], ['middleware' => 'auth']);
$router->get('/admin/kundlis', [DashboardController::class, 'kundlis'], ['middleware' => 'auth']);

// Landing
$router->get('/', function () {
    header('Location: /admin');
    exit;
});

return $router;