<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;
use PDO;

final class User
{
    public static function findByEmail(string $email): ?array
    {
        $stmt = Database::pdo()->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
        $stmt->execute([strtolower(trim($email))]);
        $row = $stmt->fetch();
        return $row === false ? null : $row;
    }

    public static function verify(string $email, string $password): ?array
    {
        $user = self::findByEmail($email);
        if ($user === null || !password_verify($password, $user['password_hash'])) {
            return null;
        }
        return $user;
    }

    public static function create(string $email, string $password, string $name = ''): array
    {
        $email = strtolower(trim($email));
        $stmt = Database::pdo()->prepare(
            'INSERT INTO users (email, password_hash, name) VALUES (?, ?, ?)'
        );
        $stmt->execute([$email, password_hash($password, PASSWORD_DEFAULT), trim($name)]);
        return [
            'id' => (int) Database::pdo()->lastInsertId(),
            'email' => $email,
            'name' => trim($name),
            'role' => 'admin',
        ];
    }

    public static function upsert(string $email, string $password, string $name = ''): array
    {
        $existing = self::findByEmail($email);
        if ($existing !== null) {
            $stmt = Database::pdo()->prepare(
                'UPDATE users SET password_hash = ?, name = ? WHERE id = ?'
            );
            $stmt->execute([password_hash($password, PASSWORD_DEFAULT), trim($name), $existing['id']]);
            $existing['name'] = trim($name) !== '' ? trim($name) : $existing['name'];
            return $existing;
        }
        return self::create($email, $password, $name);
    }
}