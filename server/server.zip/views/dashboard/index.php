<?php
function trend_bars(array $series): string {
  $max = 1;
  foreach ($series as $p) $max = max($max, (int) $p['n']);
  $html = '<div class="trend">';
  foreach ($series as $p) {
    $h = max(3, (int) round(((int) $p['n'] / $max) * 96));
    $html .= '<div class="bar" style="height:' . $h . 'px" data-n="' . e($p['n']) . '"></div>';
  }
  $html .= '</div><div class="axis"><span>' . e($series[0]['day'] ?? '') . '</span><span>' . e($series[count($series) - 1]['day'] ?? '') . '</span></div>';
  return $html;
}
$webShare = $totalClients > 0 ? round($totalInstalls / $totalClients * 100) : 0;
?>
<div class="cards">
  <div class="card">
    <div class="k">Web users</div>
    <div class="v"><?= number_format($totalClients) ?></div>
    <div class="s"><?= number_format($webToday) ?> new today</div>
  </div>
  <div class="card">
    <div class="k">Installs</div>
    <div class="v"><?= number_format($totalInstalls) ?></div>
    <div class="s ok"><?= number_format($installsToday) ?> new today</div>
  </div>
  <div class="card">
    <div class="k">Web → install</div>
    <div class="v"><?= $webShare ?>%</div>
    <div class="s">of all web users installed the PWA</div>
  </div>
  <div class="card">
    <div class="k">Kundlis saved</div>
    <div class="v"><?= number_format($totalKundlis) ?></div>
    <div class="s warn"><?= number_format($kundlisToday) ?> anonymous today</div>
  </div>
</div>

<div class="grid2">
  <div class="panel">
    <h2>New web users — last 14 days</h2>
    <?= trend_bars($clientTrend) ?>
  </div>
  <div class="panel">
    <h2>Kundlis saved — last 14 days</h2>
    <?= trend_bars($kundliTrend) ?>
  </div>
</div>

<div class="grid2">
  <div class="panel">
    <h2>Recent clients</h2>
    <table>
      <tr><th>Device</th><th>Platform</th><th>Installed</th><th>First seen</th></tr>
      <?php foreach ($recentClients as $c): ?>
      <tr>
        <td class="mono"><?= e($c['device_id']) ?></td>
        <td><?= e($c['platform']) ?: '—' ?></td>
        <td><?php if ((int)$c['is_installed']): ?><span class="pill yes">yes</span><?php else: ?><span class="pill no">web</span><?php endif; ?></td>
        <td><?= e($c['first_seen_at']) ?></td>
      </tr>
      <?php endforeach; ?>
      <?php if (!$recentClients): ?><tr><td colspan="4" class="empty">No clients yet — open the PWA once.</td></tr><?php endif; ?>
    </table>
  </div>
  <div class="panel">
    <h2>Recent kundlis</h2>
    <table>
      <tr><th>Place</th><th>Birth</th><th>Name</th></tr>
      <?php foreach ($recentKundlis as $k): ?>
      <tr>
        <td><?= e($k['place_name']) ?: '—' ?></td>
        <td class="mono"><?= e($k['date']) ?> <?= e($k['time']) ?></td>
        <td><?= e($k['birth_name']) ?: 'anonymous' ?></td>
      </tr>
      <?php endforeach; ?>
      <?php if (!$recentKundlis): ?><tr><td colspan="3" class="empty">No kundlis yet.</td></tr><?php endif; ?>
    </table>
  </div>
</div>

<?php if ($firstClient): ?>
<div class="panel muted" style="font-size:12px">Tracking since <?= e($firstClient) ?> UTC.</div>
<?php endif; ?>